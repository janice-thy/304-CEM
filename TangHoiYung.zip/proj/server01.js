var http = require('http');
var fs = require("fs");
var qs = require('querystring');

var MongoClient = require('mongodb').MongoClient;

var dbUrl = "mongodb://localhost:27017/";



http.createServer(function(request, response) {

	if(request.url === "/index"){
		sendFileContent(response, "index.html", "text/html");
	}
	else if(request.url === "/"){
		console.log("Requested URL is url" +request.url);
		response.writeHead(200, {'Content-Type': 'text/html'});
		//response.write('<b>Hey there!</b><br /><br />This is the default response. Requested URL is: ' + request.url);
	}
    else if(request.url==="/signuplogin"){
              
        if (request.method === "POST") {
            console.log("signuplogin");
        formData = '';
        msg = '';
        return request.on('data', function(data) {
          formData += data;
          console.log(formData);
          return request.on('end', function() {
            var user;
            user = qs.parse(formData);
            msg = JSON.stringify(user);
            
            info=formData.split("&");  
            var a = [];
            for(i=0; i<info.length; i++){
                
                var d=info[i].split("=");
            a[i] = d[1];    
                
            }
           
			
            console.log(a[0]);
            console.log(a[1]);
            
            stringMsg = JSON.parse(msg);
            MongoClient.connect(dbUrl, function(err, db) {

  					if (err) throw err;

  					var dbo = db.db("mydb");
					
					var myobj = stringMsg;
					
			   dbo.collection("customers").findOne({"register":a[0]},function(err, result){
						
						if(err) throw err;
						
						console.log(result);
						
						if (result != null){
							console.log("failed")
							response.end("Please enter an unique name");
						}else{

  					dbo.collection("customers").insertOne(myobj, function(err, res) {

    				if (err) throw err;
					
					console.log("1 document inserted");
					response.end("Okay!!!!");
					})
						}
    				db.close();
					});
					});
					});
  					});
            
			
		} else {
        //form = publicPath + "ajaxSignupForm.html";
        sendFileContent(response, "signuplogin.html", "text/html");
       
      };
	}
	
	

  else if(request.url==="/loginpage"){
              
        if (request.method === "POST") {
            console.log("loginpage");
             formData = '';
        msg = '';
        return request.on('data', function(data) {
          formData += data;
          console.log(formData);
          return request.on('end', function() {
            var user;
            user = qs.parse(formData);
            msg = JSON.stringify(user);
            
            info=formData.split("&");  
            var a = [];
            for(i=0; i<info.length; i++){
                
                var d=info[i].split("=");
            a[i] = d[1];    
                
            }
           
      
            console.log(a[0]);
            console.log(a[1]);
            
            stringMsg = JSON.parse(msg);

            MongoClient.connect(dbUrl, function(err, db) {

            if (err) throw err;

            var dbo = db.db("mydb");
          
          
          dbo.collection("customers").findOne({"register":a[0],"password":d[1]},function(err, result) {

          if(err) throw err;
            
            console.log(result);
            
            if (result == null){
              console.log("failed")
              response.end("Wrong user name / password. ");
            }else{

            //dbo.collection("customers").find({}).toArray(function(err, result){

            //if (err) throw err;
          
          console.log("success");
          response.end("success");
          }
            
            db.close();
          });
          });
          });
            });
            
      
    } else {
        //form = publicPath + "ajaxSignupForm.html";
        //response.end("Please sign up!!");
        sendFileContent(response, "loginpage.html", "text/html");
       
      };


       
      }

else if(request.url==="/addfav"){
              
        if (request.method === "POST") {
            console.log("favlist");
        formData = '';
        msg = '';
        return request.on('data', function(data) {
          formData += data;
          console.log(formData);
          return request.on('end', function() {
            var user;
            user = qs.parse(formData);
            msg = JSON.stringify(user);
            
            info=formData.split("&");  
            var a = [];
            for(i=0; i<info.length; i++){
                
                var d=info[i].split("=");
            a[i] = d[1];    
                
            }
           
      
            console.log("user="+a[0]);
            console.log("fav="+a[1]);
            
            stringMsg = JSON.parse(msg);
            MongoClient.connect(dbUrl, function(err, db) {

            if (err) throw err;

            var dbo = db.db("mydb");
          
          var myobj = stringMsg;

            dbo.collection("favlist").insertOne(myobj, function(err, res) {

            if (err) throw err;

            db.close();

            

            });

          });
            
            
           // request.writeHead(200, {
            //  "Content-Type": "application/json",
            //  "Content-Length": msg.length
           // });
            //return request.end("okok");
            response.end("Added!");
          });

        });
        
        
      } else {
        //form = publicPath + "ajaxSignupForm.html";
        sendFileContent(response, "index.html", "text/html");
       
      }

              
  }
	
	
else if(request.url==="/delfav"){
              
        if (request.method === "DELETE") {
            console.log("delfavlist");
            formData = '';
        msg = '';
        return request.on('data', function(data) {
          formData += data;
          console.log(formData);
          return request.on('end', function() {
            var user;
            user = qs.parse(formData);
            msg = JSON.stringify(user);
            
            info=formData.split("&");  
            var a = [];
            for(i=0; i<info.length; i++){
                
                var d=info[i].split("=");
            a[i] = d[1];    
                
            }
           
			
            console.log("user="+a[0]);
            console.log("fav="+a[1]);
            
            stringMsg = JSON.parse(msg);
            MongoClient.connect(dbUrl, function(err, db) {

  					if (err) throw err;

  					var dbo = db.db("mydb");
					
					var myobj = stringMsg;

  					dbo.collection("favlist").deleteOne(myobj, function(err, res) {

    				if (err) throw err;

    				db.close();

  					});

					});
            
            
           // request.writeHead(200, {
            //  "Content-Type": "application/json",
            //  "Content-Length": msg.length
           // });
            //return request.end("okok");
            response.end("Deleted!");
          });

        });
        
        
      } else {
        //form = publicPath + "ajaxSignupForm.html";
        sendFileContent(response, "index.html", "text/html");
       
      }       
	}

  else if(request.url==="/addwea"){
              
        if (request.method === "POST") {
            console.log("weapons");
        formData = '';
        msg = '';
        return request.on('data', function(data) {
          formData += data;
          console.log(formData);
          return request.on('end', function() {
            var user;
            user = qs.parse(formData);
            msg = JSON.stringify(user);
            
            info=formData.split("&");  
            var a = [];
            for(i=0; i<info.length; i++){
                
                var d=info[i].split("=");
            a[i] = d[1];    
                
            }
           
      
            console.log("user="+a[0]);
            console.log("weapons="+a[1]);
            
            stringMsg = JSON.parse(msg);
            MongoClient.connect(dbUrl, function(err, db) {

            if (err) throw err;

            var dbo = db.db("mydb");
          
          var myobj = stringMsg;

            dbo.collection("weapons").insertOne(myobj, function(err, res) {

            if (err) throw err;

            db.close();

            

            });

          });
            
            
           // request.writeHead(200, {
            //  "Content-Type": "application/json",
            //  "Content-Length": msg.length
           // });
            //return request.end("okok");
            response.end("Added!");
          });

        });
        
        
      } else {
        //form = publicPath + "ajaxSignupForm.html";
        sendFileContent(response, "index.html", "text/html");
       
      }

              
  }
  
  
else if(request.url==="/delwea"){
              
        if (request.method === "DELETE") {
            console.log("delweapons");
            formData = '';
        msg = '';
        return request.on('data', function(data) {
          formData += data;
          console.log(formData);
          return request.on('end', function() {
            var user;
            user = qs.parse(formData);
            msg = JSON.stringify(user);
            
            info=formData.split("&");  
            var a = [];
            for(i=0; i<info.length; i++){
                
                var d=info[i].split("=");
            a[i] = d[1];    
                
            }
           
      
            console.log("user="+a[0]);
            console.log("weapons="+a[1]);
            
            stringMsg = JSON.parse(msg);
            MongoClient.connect(dbUrl, function(err, db) {

            if (err) throw err;

            var dbo = db.db("mydb");
          
          var myobj = stringMsg;

            dbo.collection("weapons").deleteOne(myobj, function(err, res) {

            if (err) throw err;

            db.close();

            });

          });
            
            
           // request.writeHead(200, {
            //  "Content-Type": "application/json",
            //  "Content-Length": msg.length
           // });
            //return request.end("okok");
            response.end("Deleted!");
          });

        });
        
        
      } else {
        //form = publicPath + "ajaxSignupForm.html";
        sendFileContent(response, "index.html", "text/html");
       
      }       
  }
	
     
  else if(request.url==="/update"){
              
        if (request.method === "PUT") {
             formData = '';
              msg = '';

          return request.on('data', function(data) {
          formData += data;
          console.log(formData);

          return request.on('end', function() {
            var user;
            user = qs.parse(formData);
            msg = JSON.stringify(user);
            
            info=formData.split("&");  
            var a = [];
            for(i=0; i<info.length; i++){
                
                var d=info[i].split("=");
            a[i] = d[1];    
                
            }
           
      
            console.log(a[0]);
            console.log(a[1]);
            console.log(d[0]);
            console.log(d[1]);
            
            
            //stringMsg = JSON.parse(msg);

            MongoClient.connect(dbUrl, function(err, db) {

            if (err) throw err;

            var dbo = db.db("mydb");

            //var myobj = stringMsg;

            var mydata = { "register": a[0]};

            var newvalues = {  $set: {"register": a[0], "password": a[1] } };

            dbo.collection("customers").find(mydata).toArray(function(err, result) {

            if(err) throw err;
            
            console.log(result);

            if (result!=""){


          
          dbo.collection("customers").updateOne(mydata, newvalues,function(err, result)  {

          if(err) throw err;
            
            console.log("updated");
            response.end("updated");
            
            db.close();
          });
            }else{

          
          console.log("can not update");
          response.end("can not update");
          }
          
          });
          });

          });
        })
          
            
      
    } else {
        //form = publicPath + "ajaxSignupForm.html";
        //response.end("Please sign up!!");
        sendFileContent(response, "loginpage.html", "text/html");
       
      }
       
      }

      

	
  else if(/^\/[a-zA-Z0-9\/]*.js$/.test(request.url.toString())){
    sendFileContent(response, request.url.toString().substring(1), "text/javascript");
  }
  else if(/^\/[a-zA-Z0-9\/]*.css$/.test(request.url.toString())){
    sendFileContent(response, request.url.toString().substring(1), "text/css");
  }
  else if(/^\/[a-zA-Z0-9\/-/][^.]*.mobirise$/.test(request.url.toString())){
    sendFileContent(response, request.url.toString().substring(1), "text/mobirise");
  }
  else if(/^\/[a-zA-Z0-9\/-/][^.]*.touch-swipe.min.js$/.test(request.url.toString())){
    sendFileContent(response, request.url.toString().substring(1), "text/css");
  }
  else if(/^\/[a-zA-Z0-9\/-/][^.]*.js$/.test(request.url.toString())){
    sendFileContent(response, request.url.toString().substring(1), "text/javascript");
  }
  else if(/^\/[a-zA-Z0-9\/-/][^.]*.min.js$/.test(request.url.toString())){
    sendFileContent(response, request.url.toString().substring(1), "text/javascript");
  }
  else if(/^\/[a-zA-Z0-9\/-/][^.]*.min.js.map$/.test(request.url.toString())){
    sendFileContent(response, request.url.toString().substring(1), "text/map");
  }
  else if(/^\/[a-zA-Z0-9\/-/][^.]*.css.map$/.test(request.url.toString())){
    sendFileContent(response, request.url.toString().substring(1), "text/map");
  }
  else if(/^\/[a-zA-Z0-9\/-/][^.]*.min.css.map$/.test(request.url.toString())){
    sendFileContent(response, request.url.toString().substring(1), "text/map");
  }
  else if(/^\/[a-zA-Z0-9\/-/][^.]*.css$/.test(request.url.toString())){
    sendFileContent(response, request.url.toString().substring(1), "text/css");
  }
  else if(/^\/[a-zA-Z0-9\/-/][^.]*.min.css$/.test(request.url.toString())){
    sendFileContent(response, request.url.toString().substring(1), "text/css");
  }
  else if(/^\/[a-zA-Z0-9\/-/][^.]*.png$/.test(request.url.toString())){
    sendFileContent(response, request.url.toString().substring(1), "text/png");
  }
  else if(/^\/[a-zA-Z0-9\/-/][^.]*.jpg$/.test(request.url.toString())){
    sendFileContent(response, request.url.toString().substring(1), "text/jpg");
  }
  else if(/^\/[a-zA-Z0-9\/-/][^.]*.eot$/.test(request.url.toString())){
    sendFileContent(response, request.url.toString().substring(1), "text/eot");
  }
  else if(/^\/[a-zA-Z0-9\/-/][^.]*.svg$/.test(request.url.toString())){
    sendFileContent(response, request.url.toString().substring(1), "text/svg");
  }
  else if(/^\/[a-zA-Z0-9\/-/][^.]*.ttf$/.test(request.url.toString())){
    sendFileContent(response, request.url.toString().substring(1), "text/ttf");
  }
  else if(/^\/[a-zA-Z0-9\/-/][^.]*.woff$/.test(request.url.toString())){
    sendFileContent(response, request.url.toString().substring(1), "text/woff");
  }
  else if(/^\/[a-zA-Z0-9\/-/][^.]*.woff2$/.test(request.url.toString())){
    sendFileContent(response, request.url.toString().substring(1), "text/woff2");
  }
  else if(/^\/[a-zA-Z0-9\/-/][^.]*.html$/.test(request.url.toString())){
    sendFileContent(response, request.url.toString().substring(1), "text/html");
  }
  else if(/^\/[a-zA-Z0-9\/-/][^.]*.ico$/.test(request.url.toString())){
    sendFileContent(response, request.url.toString().substring(1), "text/ico");
  }
  else if(/^\/[a-zA-Z0-9\/-/][^.]*.bundle.min.js$/.test(request.url.toString())){
    sendFileContent(response, request.url.toString().substring(1), "text/ico");
  }
  else if(/^\/[a-zA-Z0-9\/-/][^.]*.jquery.min$/.test(request.url.toString())){
    sendFileContent(response, request.url.toString().substring(1), "text/ico");
  }
  else if(/^\/[a-zA-Z0-9\/-/][^.]*.easing.min.js$/.test(request.url.toString())){
    sendFileContent(response, request.url.toString().substring(1), "text/ico");
  }
  else if(/^\/[a-zA-Z0-9\/-/][^.]*.agency.min$/.test(request.url.toString())){
    sendFileContent(response, request.url.toString().substring(1), "text/ico");
  }
  else if(/^\/[a-zA-Z0-9\/-/][^.]*.woff$/.test(request.url.toString())){
    sendFileContent(response, request.url.toString().substring(1), "text/ico");
  }
  else if(/^\/[a-zA-Z0-9\/-/][^.]*.woff2$/.test(request.url.toString())){
    sendFileContent(response, request.url.toString().substring(1), "text/ico");
  }
  else if(/^\/[a-zA-Z0-9\/-/][^.]*.ttf$/.test(request.url.toString())){
    sendFileContent(response, request.url.toString().substring(1), "text/ico");
  }
  else if(/^\/[a-zA-Z0-9\/-/][^.]*.bundle.min.js.map$/.test(request.url.toString())){
    sendFileContent(response, request.url.toString().substring(1), "text/ico");
  }
  else{
		console.log("Requested URL is: " + request.url);
		response.end();
	}
}).listen(9999)

function sendFileContent(response, fileName, contentType){
	fs.readFile(fileName, function(err, data){
		if(err){
			response.writeHead(404);
			response.write("Not Found!");
		}
		else{
			response.writeHead(200, {'Content-Type': contentType});
			response.write(data);
		}
		response.end();
	});
}